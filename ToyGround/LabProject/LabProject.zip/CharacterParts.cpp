#include "pch.h"
#include "CharacterParts.h"

CharacterParts::CharacterParts(std::string type, std::string id) :
	GameObject(type, id)
{
}

CharacterParts::~CharacterParts()
{
}
