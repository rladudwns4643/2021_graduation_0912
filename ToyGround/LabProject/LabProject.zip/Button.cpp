#include "pch.h"
#include "Button.h"

Button::Button(std::string type, std::string id) :
	UserInterface(type, id)
{
}

Button::~Button()
{
}