#include "pch.h"
#include "Scene.h"

Scene::Scene() : m_SceneController(nullptr)
{
}

Scene::~Scene()
{
}