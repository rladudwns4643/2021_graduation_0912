#include "pch.h"
#include "ImageView.h"

ImageView::ImageView(std::string type, std::string id) :
	UserInterface(type, id)
{
}

ImageView::~ImageView()
{
}
